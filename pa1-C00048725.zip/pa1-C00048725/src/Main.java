// Derek Scott
// C00048725
// CMPS 260
// Programming Assignment: 1
// Due Date : 2/9/2023
// Program Description
// Emphasizes the use of class Scanner to parse user keyboard input and iterate over String
// variables as well as the use of loop control structures and class Math to produce
// randomized String output.
// Certificate of Authenticity:
// I certify the code in method function main of this project is based
// entirely on my own construction, but I received assistance from Gabe
// who is a peer mentor.
// Gabe clarified the structure of the randomized loop to me as I had
// overcomplicated it.

//Scanner needed.
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        // Need input from the user.
        Scanner input = new Scanner(System.in);

        //Variables for subjects, input for subjects, counting loop for subjects, and word randomizer for subjects.
        int subjectCount = 0;
        String randomSubject = "";

        //Input from the user.
        System.out.println("Enter a list of subject nouns separated by spaces: ");
        String subjects = input.nextLine();
        Scanner subjectScanner = new Scanner(subjects);

        //Counts the number of words in the string
        while (subjectScanner.hasNext()) {
            subjectScanner.next();
            subjectCount++;
        }

        subjectScanner = new Scanner(subjects);
        int randomSubjectNumber = (int) (Math.random() * (subjectCount));

        //Loops a random amount of times, determining which word is read.
        while (randomSubjectNumber >= 0) {
            randomSubject = subjectScanner.next();
            randomSubjectNumber--;
        }

        //Variables for verbs, input for verbs, counting loop for verbs, and word randomizer for verbs.
        int verbCount = 0;
        String randomVerb = "";

        //Input from the user.
        System.out.println("Enter a list of verbs separated by spaces: ");
        String verbs = input.nextLine();
        Scanner verbScanner = new Scanner(verbs);

        //Counts the number of words in the string
        while (verbScanner.hasNext()) {
            verbScanner.next();
            verbCount++;
        }

        verbScanner = new Scanner(verbs);
        int randomVerbNumber = (int) (Math.random() * (verbCount));

        //Loops a random amount of times, determining which word is read.
        while (randomVerbNumber >= 0) {
            randomVerb = verbScanner.next();
            randomVerbNumber--;
        }

        //Variables for adjectives
        int adjectiveCount = 0;
        String randomAdjective = "";

        //Input from the user.
        System.out.println("Enter a list of adjectives separated by spaces: ");
        String adjectives = input.nextLine();
        Scanner adjectiveScanner = new Scanner(adjectives);

        //Counts the number of words in the string
        while (adjectiveScanner.hasNext()) {
            adjectiveScanner.next();
            adjectiveCount++;
        }

        adjectiveScanner = new Scanner(adjectives);
        int randomAdjectiveNumber = (int) (Math.random() * (adjectiveCount));

        //Loops a random amount of times, determining which word is read.
        while (randomAdjectiveNumber >= 0) {
            randomAdjective = adjectiveScanner.next();
            randomAdjectiveNumber--;
        }

        //Variables for objects, input for objects, counting loop for objects, and word randomizer for objects.
        int objectCount = 0;
        String randomObject = "";

        //Input from the user.
        System.out.println("Enter a list of object nouns separated by spaces: ");
        String objects = input.nextLine();
        Scanner objectScanner = new Scanner(objects);

        //Counts the number of words in the string
        while (objectScanner.hasNext()) {
            objectScanner.next();
            objectCount++;
        }

        objectScanner = new Scanner(objects);
        int randomObjectNumber = (int) (Math.random() * (objectCount));

        //Loops a random amount of times, determining which word is read.
        while (randomObjectNumber >= 0) {
            randomObject = objectScanner.next();
            randomObjectNumber--;
        }

        //Article agreement for subjects.
        String article1;
        if ((randomSubject.charAt(randomSubject.length() - 1) == 's')) {
            article1 = "The";
        } else if (randomSubject.charAt(0) == 'a' || randomSubject.charAt(0) == 'e' || randomSubject.charAt(0) == 'i'
                || randomSubject.charAt(0) == 'o' || randomSubject.charAt(0) == 'u') {
            article1 = "An";
        } else {
            article1 = "A";
        }

        //Article agreement for adjective.
        String article2;
        if ((randomObject.charAt(randomObject.length() - 1) == 's')) {
            article2 = "the";
        } else if (randomAdjective.charAt(0) == 'a' || randomAdjective.charAt(0) == 'e' || randomAdjective.charAt(0) == 'i'
                || randomAdjective.charAt(0) == 'o' || randomAdjective.charAt(0) == 'u')
        {
            article2 = "an";
        } else {
            article2 = "a";
        }

        //First iteration of Mad-Libs
        System.out.println(article1 + " " + randomSubject + " " + randomVerb + " " + article2 + " " + randomAdjective + " " + randomObject + ".");

        System.out.println("There are " + subjectCount + " subject nouns.");
        System.out.println("There are " + verbCount + " verbs.");
        System.out.println("There are " + adjectiveCount + " adjectives.");
        System.out.println("There are " + objectCount + " object nouns.");

        //Copy and paste of code above for second iteration of Mad-Libs (minus some initialization and the need to count the number of words).
        subjectScanner = new Scanner(subjects);
        randomSubjectNumber = (int) (Math.random() * (subjectCount));
        while (randomSubjectNumber >= 0)
        {
            randomSubject = subjectScanner.next();
            randomSubjectNumber--;
        }

        verbScanner = new Scanner(verbs);
        randomVerbNumber = (int) (Math.random() * (verbCount));
        while (randomVerbNumber >= 0)
        {
            randomVerb = verbScanner.next();
            randomVerbNumber--;
        }

        adjectiveScanner = new Scanner(adjectives);
        randomAdjectiveNumber = (int) (Math.random() * (adjectiveCount));
        while (randomAdjectiveNumber >= 0)
        {
            randomAdjective = adjectiveScanner.next();
            randomAdjectiveNumber--;
        }

        objectScanner = new Scanner(objects);
        randomObjectNumber = (int) (Math.random() * (objectCount));
        while (randomObjectNumber >= 0)
        {
            randomObject = objectScanner.next();
            randomObjectNumber--;
        }

        //Article agreement for subjects.
        if ((randomSubject.charAt(randomSubject.length() - 1) == 's'))
        {
            article1 = "The";
        } else if (randomSubject.charAt(0) == 'a' || randomSubject.charAt(0) == 'e' || randomSubject.charAt(0) == 'i'
                || randomSubject.charAt(0) == 'o' || randomSubject.charAt(0) == 'u') {
            article1 = "An";
        } else {
            article1 = "A";
        }

        //Article agreement for adjective.
        if ((randomObject.charAt(randomObject.length() - 1) == 's')) {
            article2 = "the";
        } else if (randomAdjective.charAt(0) == 'a' || randomAdjective.charAt(0) == 'e' || randomAdjective.charAt(0) == 'i'
                || randomAdjective.charAt(0) == 'o' || randomAdjective.charAt(0) == 'u')
        {
            article2 = "an";
        } else {
            article2 = "a";
        }

        //Second iteration of Mad-Libs
        System.out.println(article1 + " " + randomSubject + " " + randomVerb + " " + article2 + " " + randomAdjective + " " + randomObject + ".");

    }
}