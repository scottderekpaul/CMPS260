// Derek Scott
// c00048725
// CMPS 260
// Programming Assignment : 2
// Due Date : 3/1/2023
// Program Description: Emphasizes the use of methods and loops to allow the user to repeatedly choose from a
// number of menu items and executes the appropriate method with input from the user.
// Certificate of Authenticity:
// I certify the code in method function main of this project is based
// entirely on my own knowledge and is the result of solely my own work.

import java.util.Scanner;
public class Main {
    public static void main(String[] args)
    {
        printMenu();
    }

    //prints the menu for the main.
    public static void printMenu() {

        int userInput = 0;
        Scanner input = new Scanner(System.in);

        while (userInput != 1) {
            System.out.println( "Enter ’1’ to count punctuation symbols in a String.\n" +
                                "Enter ’2’ to convert characters to binary.\n" +
                                "Enter ’3’ to convert 8-bit binary to a character.\n" +
                                "Enter ’4’ to exit");
            userInput = input.nextInt();
        }

    }
}